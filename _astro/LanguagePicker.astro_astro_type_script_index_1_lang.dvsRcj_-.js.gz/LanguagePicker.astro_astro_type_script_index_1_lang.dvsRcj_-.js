import"./SocialShare.astro_astro_type_script_index_1_lang.C64e_66r.js";
